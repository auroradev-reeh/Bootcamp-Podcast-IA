Arquivo Prompt MidJourney - BOOTCAMP IA

Capa:
	
	Prompt Midjorney:
	
	A cute and charismatic anthropomorphic insect, wearing a red and gold Gryffindor-style scarf, holding a wand whose tip is shaped like a podcast microphone. The insect should have expressive eyes and a friendly, curious smile, blending fantasy and technology vibes. The background should be softly magical with hints of digital code patterns subtly glowing in the air, evoking a fusion between wizardry and computer programming. The overall atmosphere should be warm, creative, and inviting, suitable for a podcast cover. Include lighting that highlights the insect and its wand, with a soft vignette for focus. Render in a semi-realistic illustration style with smooth textures and vibrant yet balanced colors. 
	--ar 1:1 --v 6 --style raw --q 2 --s 700 --uplight
